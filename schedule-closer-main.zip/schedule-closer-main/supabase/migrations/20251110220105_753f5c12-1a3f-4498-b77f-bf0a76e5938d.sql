-- Create custom time slots table for exceptions and extra hours
CREATE TABLE public.custom_time_slots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  closer_id UUID REFERENCES public.closers(id) ON DELETE CASCADE NOT NULL,
  date DATE NOT NULL,
  time TIME NOT NULL,
  is_available BOOLEAN DEFAULT true,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(closer_id, date, time)
);

-- Enable RLS
ALTER TABLE public.custom_time_slots ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to custom_time_slots" ON public.custom_time_slots FOR SELECT USING (true);
CREATE POLICY "Allow public insert to custom_time_slots" ON public.custom_time_slots FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update to custom_time_slots" ON public.custom_time_slots FOR UPDATE USING (true);
CREATE POLICY "Allow public delete to custom_time_slots" ON public.custom_time_slots FOR DELETE USING (true);

-- Create index for better performance
CREATE INDEX idx_custom_time_slots_closer_date ON public.custom_time_slots(closer_id, date);