-- Create funnels table
CREATE TABLE public.funnels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.funnels ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to funnels" ON public.funnels FOR SELECT USING (true);
CREATE POLICY "Allow public insert to funnels" ON public.funnels FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update to funnels" ON public.funnels FOR UPDATE USING (true);
CREATE POLICY "Allow public delete to funnels" ON public.funnels FOR DELETE USING (true);

-- Insert default funnels
INSERT INTO public.funnels (name, description)
VALUES 
  ('Facebook Ads', 'Leads vindos do Facebook Ads'),
  ('Google Ads', 'Leads vindos do Google Ads'),
  ('Instagram', 'Leads vindos do Instagram'),
  ('Indicação', 'Leads vindos de indicações'),
  ('Site/Orgânico', 'Leads vindos do site ou busca orgânica');