-- Create closers table
CREATE TABLE public.closers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create appointments table
CREATE TABLE public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  closer_id UUID REFERENCES public.closers(id) ON DELETE CASCADE NOT NULL,
  lead_name TEXT NOT NULL,
  funnel TEXT NOT NULL,
  scheduled_date DATE NOT NULL,
  scheduled_time TIME NOT NULL,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'no_show')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create time slots configuration table
CREATE TABLE public.time_slots_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time TIME NOT NULL DEFAULT '08:30:00',
  end_time TIME NOT NULL DEFAULT '18:00:00',
  slot_duration_minutes INTEGER NOT NULL DEFAULT 75,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(day_of_week)
);

-- Insert default time slots configuration (Monday to Friday)
INSERT INTO public.time_slots_config (day_of_week, start_time, end_time, slot_duration_minutes)
VALUES 
  (1, '08:30:00', '18:00:00', 75),
  (2, '08:30:00', '18:00:00', 75),
  (3, '08:30:00', '18:00:00', 75),
  (4, '08:30:00', '18:00:00', 75),
  (5, '08:30:00', '18:00:00', 75);

-- Enable RLS
ALTER TABLE public.closers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.time_slots_config ENABLE ROW LEVEL SECURITY;

-- Create policies (public access for now - adjust based on auth requirements)
CREATE POLICY "Allow public read access to closers" ON public.closers FOR SELECT USING (true);
CREATE POLICY "Allow public insert to closers" ON public.closers FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update to closers" ON public.closers FOR UPDATE USING (true);
CREATE POLICY "Allow public delete to closers" ON public.closers FOR DELETE USING (true);

CREATE POLICY "Allow public read access to appointments" ON public.appointments FOR SELECT USING (true);
CREATE POLICY "Allow public insert to appointments" ON public.appointments FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update to appointments" ON public.appointments FOR UPDATE USING (true);
CREATE POLICY "Allow public delete to appointments" ON public.appointments FOR DELETE USING (true);

CREATE POLICY "Allow public read access to time_slots_config" ON public.time_slots_config FOR SELECT USING (true);
CREATE POLICY "Allow public update to time_slots_config" ON public.time_slots_config FOR UPDATE USING (true);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for appointments
CREATE TRIGGER update_appointments_updated_at
BEFORE UPDATE ON public.appointments
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_appointments_closer_id ON public.appointments(closer_id);
CREATE INDEX idx_appointments_scheduled_date ON public.appointments(scheduled_date);
CREATE INDEX idx_appointments_status ON public.appointments(status);