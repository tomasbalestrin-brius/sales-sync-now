import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, UserPlus, Mail, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Closer {
  id: string;
  name: string;
  email: string;
  is_active: boolean;
  created_at: string;
}

const ClosersManagement = () => {
  const navigate = useNavigate();
  const [closers, setClosers] = useState<Closer[]>([]);
  const [newCloser, setNewCloser] = useState({ name: "", email: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchClosers();
  }, []);

  const fetchClosers = async () => {
    const { data } = await supabase
      .from("closers")
      .select("*")
      .order("created_at", { ascending: false });
    setClosers(data || []);
  };

  const handleAddCloser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCloser.name || !newCloser.email) {
      toast.error("Preencha todos os campos");
      return;
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.from("closers").insert({
        name: newCloser.name,
        email: newCloser.email,
        is_active: true,
      });

      if (error) throw error;

      toast.success("Closer adicionado com sucesso!");
      setNewCloser({ name: "", email: "" });
      fetchClosers();
    } catch (error: any) {
      console.error("Error adding closer:", error);
      toast.error(error.message || "Erro ao adicionar closer");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("closers")
        .update({ is_active: !currentStatus })
        .eq("id", id);

      if (error) throw error;

      toast.success(`Closer ${!currentStatus ? "ativado" : "desativado"} com sucesso!`);
      fetchClosers();
    } catch (error) {
      console.error("Error updating closer:", error);
      toast.error("Erro ao atualizar closer");
    }
  };

  const handleDeleteCloser = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este closer?")) return;

    try {
      const { error } = await supabase.from("closers").delete().eq("id", id);

      if (error) throw error;

      toast.success("Closer excluído com sucesso!");
      fetchClosers();
    } catch (error) {
      console.error("Error deleting closer:", error);
      toast.error("Erro ao excluir closer");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="container mx-auto max-w-6xl">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Add New Closer Form */}
          <Card className="shadow-xl lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="h-5 w-5" />
                Adicionar Closer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddCloser} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome</Label>
                  <Input
                    id="name"
                    value={newCloser.name}
                    onChange={(e) => setNewCloser({ ...newCloser, name: e.target.value })}
                    placeholder="Nome do closer"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newCloser.email}
                    onChange={(e) => setNewCloser({ ...newCloser, email: e.target.value })}
                    placeholder="email@exemplo.com"
                    required
                  />
                </div>

                <Button type="submit" disabled={isSubmitting} className="w-full">
                  {isSubmitting ? "Adicionando..." : "Adicionar Closer"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Closers List */}
          <Card className="shadow-xl lg:col-span-2">
            <CardHeader>
              <CardTitle>Closers Cadastrados</CardTitle>
            </CardHeader>
            <CardContent>
              {closers.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Nenhum closer cadastrado ainda
                </p>
              ) : (
                <div className="space-y-4">
                  {closers.map((closer) => (
                    <div
                      key={closer.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="font-semibold text-lg">{closer.name}</div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Mail className="h-3 w-3" />
                          {closer.email}
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <Label htmlFor={`active-${closer.id}`} className="text-sm">
                            {closer.is_active ? "Ativo" : "Inativo"}
                          </Label>
                          <Switch
                            id={`active-${closer.id}`}
                            checked={closer.is_active}
                            onCheckedChange={() => handleToggleActive(closer.id, closer.is_active)}
                          />
                        </div>

                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteCloser(closer.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ClosersManagement;
