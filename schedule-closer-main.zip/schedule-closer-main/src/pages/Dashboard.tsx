import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, Users, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface DashboardStats {
  totalAppointments: number;
  todayAppointments: number;
  activeClosers: number;
  completionRate: number;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats>({
    totalAppointments: 0,
    todayAppointments: 0,
    activeClosers: 0,
    completionRate: 0,
  });
  const [todayAppointmentsList, setTodayAppointmentsList] = useState<any[]>([]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    const today = format(new Date(), "yyyy-MM-dd");

    // Fetch total appointments
    const { count: totalCount } = await supabase
      .from("appointments")
      .select("*", { count: "exact", head: true });

    // Fetch today's appointments
    const { data: todayData, count: todayCount } = await supabase
      .from("appointments")
      .select("*, closers(name)")
      .eq("scheduled_date", today)
      .order("scheduled_time");

    // Fetch active closers
    const { count: closersCount } = await supabase
      .from("closers")
      .select("*", { count: "exact", head: true })
      .eq("is_active", true);

    // Calculate completion rate
    const { count: completedCount } = await supabase
      .from("appointments")
      .select("*", { count: "exact", head: true })
      .eq("status", "completed");

    const rate = totalCount && completedCount ? (completedCount / totalCount) * 100 : 0;

    setStats({
      totalAppointments: totalCount || 0,
      todayAppointments: todayCount || 0,
      activeClosers: closersCount || 0,
      completionRate: Math.round(rate),
    });

    setTodayAppointmentsList(todayData || []);
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      scheduled: "bg-primary/10 text-primary",
      completed: "bg-accent/10 text-accent",
      cancelled: "bg-destructive/10 text-destructive",
      no_show: "bg-warning/10 text-warning",
    };
    return styles[status as keyof typeof styles] || styles.scheduled;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Gestão de Agendamentos
            </h1>
            <p className="text-muted-foreground mt-2">
              {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </p>
          </div>
          <Button
            onClick={() => navigate("/appointments/new")}
            size="lg"
            className="shadow-lg hover:shadow-xl transition-shadow"
          >
            <Calendar className="mr-2 h-5 w-5" />
            Novo Agendamento
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total de Agendamentos</CardTitle>
              <Calendar className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{stats.totalAppointments}</div>
            </CardContent>
          </Card>

          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Agendamentos Hoje</CardTitle>
              <Clock className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-warning">{stats.todayAppointments}</div>
            </CardContent>
          </Card>

          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Closers Ativos</CardTitle>
              <Users className="h-4 w-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-accent">{stats.activeClosers}</div>
            </CardContent>
          </Card>

          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{stats.completionRate}%</div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          <Button
            variant="outline"
            size="lg"
            className="h-24 text-lg"
            onClick={() => navigate("/calendar")}
          >
            <Calendar className="mr-2 h-6 w-6" />
            Ver Calendário
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="h-24 text-lg"
            onClick={() => navigate("/closers")}
          >
            <Users className="mr-2 h-6 w-6" />
            Cadastrar Closers
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="h-24 text-lg"
            onClick={() => navigate("/funnels")}
          >
            <TrendingUp className="mr-2 h-6 w-6" />
            Cadastrar Funis
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="h-24 text-lg"
            onClick={() => navigate("/settings")}
          >
            <Clock className="mr-2 h-6 w-6" />
            Configurar Padrões
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="h-24 text-lg"
            onClick={() => navigate("/custom-schedule")}
          >
            <Clock className="mr-2 h-6 w-6" />
            Adicionar Horários
          </Button>
        </div>

        {/* Today's Appointments */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Agendamentos de Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            {todayAppointmentsList.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Nenhum agendamento para hoje
              </p>
            ) : (
              <div className="space-y-4">
                {todayAppointmentsList.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex-1">
                      <div className="font-semibold">{appointment.lead_name}</div>
                      <div className="text-sm text-muted-foreground">
                        Closer: {appointment.closers?.name} • Funil: {appointment.funnel}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-medium">
                        {format(new Date(`2000-01-01T${appointment.scheduled_time}`), "HH:mm")}
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(
                          appointment.status
                        )}`}
                      >
                        {appointment.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
