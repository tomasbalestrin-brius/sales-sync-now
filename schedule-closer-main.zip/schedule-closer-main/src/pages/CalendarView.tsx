import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { format, addWeeks, startOfWeek, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Appointment {
  id: string;
  lead_name: string;
  funnel: string;
  scheduled_time: string;
  status: string;
}

interface Closer {
  id: string;
  name: string;
}

const CalendarView = () => {
  const navigate = useNavigate();
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [closers, setClosers] = useState<Closer[]>([]);
  const [selectedCloser, setSelectedCloser] = useState<string>("all");
  const [appointments, setAppointments] = useState<Record<string, Appointment[]>>({});

  useEffect(() => {
    fetchClosers();
  }, []);

  useEffect(() => {
    fetchAppointments();
  }, [currentWeek, selectedCloser]);

  const fetchClosers = async () => {
    const { data } = await supabase
      .from("closers")
      .select("id, name")
      .eq("is_active", true)
      .order("name");
    setClosers(data || []);
  };

  const fetchAppointments = async () => {
    const weekDays = Array.from({ length: 5 }, (_, i) => addDays(currentWeek, i));
    const startDate = format(weekDays[0], "yyyy-MM-dd");
    const endDate = format(weekDays[4], "yyyy-MM-dd");

    let query = supabase
      .from("appointments")
      .select("id, lead_name, funnel, scheduled_date, scheduled_time, status, closer_id")
      .gte("scheduled_date", startDate)
      .lte("scheduled_date", endDate)
      .order("scheduled_time");

    if (selectedCloser !== "all") {
      query = query.eq("closer_id", selectedCloser);
    }

    const { data } = await query;

    const appointmentsByDate: Record<string, Appointment[]> = {};
    data?.forEach((apt) => {
      if (!appointmentsByDate[apt.scheduled_date]) {
        appointmentsByDate[apt.scheduled_date] = [];
      }
      appointmentsByDate[apt.scheduled_date].push(apt);
    });

    setAppointments(appointmentsByDate);
  };

  const weekDays = Array.from({ length: 5 }, (_, i) => addDays(currentWeek, i));

  const getStatusColor = (status: string) => {
    const colors = {
      scheduled: "bg-primary/20 border-primary",
      completed: "bg-accent/20 border-accent",
      cancelled: "bg-destructive/20 border-destructive",
      no_show: "bg-warning/20 border-warning",
    };
    return colors[status as keyof typeof colors] || colors.scheduled;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="container mx-auto">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>

        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-3xl">Calendário de Agendamentos</CardTitle>
              <div className="flex items-center gap-4">
                <Select value={selectedCloser} onValueChange={setSelectedCloser}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Todos os closers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os closers</SelectItem>
                    {closers.map((closer) => (
                      <SelectItem key={closer.id} value={closer.id}>
                        {closer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentWeek(addWeeks(currentWeek, -1))}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" onClick={() => setCurrentWeek(startOfWeek(new Date(), { weekStartsOn: 1 }))}>
                    Hoje
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentWeek(addWeeks(currentWeek, 1))}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-4">
              {weekDays.map((day) => {
                const dateKey = format(day, "yyyy-MM-dd");
                const dayAppointments = appointments[dateKey] || [];

                return (
                  <div key={dateKey} className="space-y-2">
                    <div className="text-center pb-2 border-b">
                      <div className="font-semibold">
                        {format(day, "EEEE", { locale: ptBR })}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {format(day, "dd/MM")}
                      </div>
                    </div>

                    <div className="space-y-2 min-h-[300px]">
                      {dayAppointments.length === 0 ? (
                        <p className="text-center text-sm text-muted-foreground py-4">
                          Sem agendamentos
                        </p>
                      ) : (
                        dayAppointments.map((apt) => (
                          <div
                            key={apt.id}
                            className={`p-2 rounded border-l-4 text-xs ${getStatusColor(apt.status)}`}
                          >
                            <div className="font-semibold">
                              {format(new Date(`2000-01-01T${apt.scheduled_time}`), "HH:mm")}
                            </div>
                            <div className="truncate">{apt.lead_name}</div>
                            <div className="text-muted-foreground truncate">{apt.funnel}</div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CalendarView;
