import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Clock, Plus } from "lucide-react";
import { toast } from "sonner";

interface TimeSlotConfig {
  id: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  slot_duration_minutes: number;
  is_active: boolean;
}

const weekDays = [
  { value: 1, label: "Segunda-feira" },
  { value: 2, label: "Terça-feira" },
  { value: 3, label: "Quarta-feira" },
  { value: 4, label: "Quinta-feira" },
  { value: 5, label: "Sexta-feira" },
];

const Settings = () => {
  const navigate = useNavigate();
  const [configs, setConfigs] = useState<TimeSlotConfig[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchConfigs();
  }, []);

  const fetchConfigs = async () => {
    const { data } = await supabase
      .from("time_slots_config")
      .select("*")
      .order("day_of_week");
    setConfigs(data || []);
  };

  const handleUpdateConfig = async (
    id: string,
    field: keyof TimeSlotConfig,
    value: any
  ) => {
    try {
      const { error } = await supabase
        .from("time_slots_config")
        .update({ [field]: value })
        .eq("id", id);

      if (error) throw error;

      toast.success("Configuração atualizada!");
      fetchConfigs();
    } catch (error) {
      console.error("Error updating config:", error);
      toast.error("Erro ao atualizar configuração");
    }
  };

  const handleBulkUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const updates = configs.map((config) =>
        supabase
          .from("time_slots_config")
          .update({
            start_time: config.start_time,
            end_time: config.end_time,
            slot_duration_minutes: config.slot_duration_minutes,
            is_active: config.is_active,
          })
          .eq("id", config.id)
      );

      await Promise.all(updates);
      toast.success("Todas as configurações foram salvas!");
    } catch (error) {
      console.error("Error saving configs:", error);
      toast.error("Erro ao salvar configurações");
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateLocalConfig = (id: string, field: keyof TimeSlotConfig, value: any) => {
    setConfigs((prev) =>
      prev.map((config) =>
        config.id === id ? { ...config, [field]: value } : config
      )
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="container mx-auto max-w-4xl">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>

        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-3xl">
                  <Clock className="h-8 w-8" />
                  Configuração de Horários Padrão
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  Configure os horários padrão de funcionamento para cada dia da semana.
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => navigate("/custom-schedule")}
              >
                <Plus className="mr-2 h-4 w-4" />
                Adicionar Horários
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleBulkUpdate} className="space-y-6">
              {weekDays.map((day) => {
                const config = configs.find((c) => c.day_of_week === day.value);
                if (!config) return null;

                return (
                  <Card key={config.id} className="border-2">
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold">{day.label}</h3>
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`active-${config.id}`}>
                              {config.is_active ? "Ativo" : "Inativo"}
                            </Label>
                            <Switch
                              id={`active-${config.id}`}
                              checked={config.is_active}
                              onCheckedChange={(checked) =>
                                updateLocalConfig(config.id, "is_active", checked)
                              }
                            />
                          </div>
                        </div>

                        <div className="grid gap-4 md:grid-cols-3">
                          <div className="space-y-2">
                            <Label htmlFor={`start-${config.id}`}>
                              Horário Inicial
                            </Label>
                            <Input
                              id={`start-${config.id}`}
                              type="time"
                              value={config.start_time}
                              onChange={(e) =>
                                updateLocalConfig(
                                  config.id,
                                  "start_time",
                                  e.target.value
                                )
                              }
                              disabled={!config.is_active}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor={`end-${config.id}`}>
                              Horário Final
                            </Label>
                            <Input
                              id={`end-${config.id}`}
                              type="time"
                              value={config.end_time}
                              onChange={(e) =>
                                updateLocalConfig(
                                  config.id,
                                  "end_time",
                                  e.target.value
                                )
                              }
                              disabled={!config.is_active}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor={`duration-${config.id}`}>
                              Duração (minutos)
                            </Label>
                            <Input
                              id={`duration-${config.id}`}
                              type="number"
                              min="15"
                              step="15"
                              value={config.slot_duration_minutes}
                              onChange={(e) =>
                                updateLocalConfig(
                                  config.id,
                                  "slot_duration_minutes",
                                  parseInt(e.target.value)
                                )
                              }
                              disabled={!config.is_active}
                            />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              <div className="flex gap-4 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/")}
                  className="flex-1"
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={isSubmitting} className="flex-1">
                  {isSubmitting ? "Salvando..." : "Salvar Configurações"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Settings;
