import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, CalendarIcon, Clock, Trash2, Plus } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Closer {
  id: string;
  name: string;
}

interface CustomSlot {
  id: string;
  closer_id: string;
  date: string;
  time: string;
  is_available: boolean;
  reason: string | null;
  closers: { name: string };
}

const CustomSchedule = () => {
  const navigate = useNavigate();
  const [closers, setClosers] = useState<Closer[]>([]);
  const [customSlots, setCustomSlots] = useState<CustomSlot[]>([]);
  const [selectedCloser, setSelectedCloser] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState("");
  const [isAvailable, setIsAvailable] = useState(true);
  const [reason, setReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchClosers();
    fetchCustomSlots();
  }, []);

  const fetchClosers = async () => {
    const { data } = await supabase
      .from("closers")
      .select("id, name")
      .eq("is_active", true)
      .order("name");
    setClosers(data || []);
  };

  const fetchCustomSlots = async () => {
    const { data } = await supabase
      .from("custom_time_slots")
      .select("*, closers(name)")
      .order("date", { ascending: false })
      .order("time");
    setCustomSlots(data || []);
  };

  const handleAddSlot = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedCloser || !selectedDate || !selectedTime) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase.from("custom_time_slots").insert({
        closer_id: selectedCloser,
        date: format(selectedDate, "yyyy-MM-dd"),
        time: selectedTime,
        is_available: isAvailable,
        reason: reason || null,
      });

      if (error) throw error;

      toast.success("Horário personalizado adicionado!");
      setSelectedCloser("");
      setSelectedDate(undefined);
      setSelectedTime("");
      setReason("");
      setIsAvailable(true);
      fetchCustomSlots();
    } catch (error: any) {
      console.error("Error adding custom slot:", error);
      toast.error(error.message || "Erro ao adicionar horário");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteSlot = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este horário?")) return;

    try {
      const { error } = await supabase.from("custom_time_slots").delete().eq("id", id);

      if (error) throw error;

      toast.success("Horário excluído com sucesso!");
      fetchCustomSlots();
    } catch (error) {
      console.error("Error deleting slot:", error);
      toast.error("Erro ao excluir horário");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="container mx-auto max-w-6xl">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Add Custom Slot Form */}
          <Card className="shadow-xl lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Adicionar Horário
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddSlot} className="space-y-4">
                <div className="space-y-2">
                  <Label>Closer</Label>
                  <Select value={selectedCloser} onValueChange={setSelectedCloser} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um closer" />
                    </SelectTrigger>
                    <SelectContent>
                      {closers.map((closer) => (
                        <SelectItem key={closer.id} value={closer.id}>
                          {closer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Data</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !selectedDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {selectedDate
                          ? format(selectedDate, "PPP", { locale: ptBR })
                          : "Selecione uma data"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        disabled={(date) => date < new Date()}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">Horário</Label>
                  <Input
                    id="time"
                    type="time"
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="available">Disponível para agendamento</Label>
                    <Switch
                      id="available"
                      checked={isAvailable}
                      onCheckedChange={setIsAvailable}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {isAvailable
                      ? "Este horário estará disponível para agendamentos"
                      : "Este horário será bloqueado (não disponível)"}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reason">Motivo/Observação</Label>
                  <Textarea
                    id="reason"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Ex: Horário extra, Reunião interna, Folga..."
                    rows={3}
                  />
                </div>

                <Button type="submit" disabled={isSubmitting} className="w-full">
                  {isSubmitting ? "Adicionando..." : "Adicionar Horário"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Custom Slots List */}
          <Card className="shadow-xl lg:col-span-2">
            <CardHeader>
              <CardTitle>Horários Personalizados</CardTitle>
            </CardHeader>
            <CardContent>
              {customSlots.length === 0 ? (
                <div className="text-center py-8">
                  <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    Nenhum horário personalizado cadastrado
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Use o formulário ao lado para adicionar horários extras ou bloquear horários
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {customSlots.map((slot) => (
                    <div
                      key={slot.id}
                      className={cn(
                        "flex items-center justify-between p-4 border rounded-lg transition-colors",
                        slot.is_available
                          ? "bg-accent/10 border-accent/30 hover:bg-accent/20"
                          : "bg-destructive/10 border-destructive/30 hover:bg-destructive/20"
                      )}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="font-semibold">{slot.closers.name}</div>
                          <span
                            className={cn(
                              "px-2 py-0.5 rounded text-xs font-medium",
                              slot.is_available
                                ? "bg-accent text-accent-foreground"
                                : "bg-destructive text-destructive-foreground"
                            )}
                          >
                            {slot.is_available ? "Disponível" : "Bloqueado"}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <span className="font-medium">
                            {format(new Date(slot.date), "dd/MM/yyyy", { locale: ptBR })}
                          </span>
                          {" • "}
                          <span>{format(new Date(`2000-01-01T${slot.time}`), "HH:mm")}</span>
                        </div>
                        {slot.reason && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {slot.reason}
                          </div>
                        )}
                      </div>

                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteSlot(slot.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CustomSchedule;
