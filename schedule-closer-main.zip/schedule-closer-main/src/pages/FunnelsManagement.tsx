import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Filter, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Funnel {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

const FunnelsManagement = () => {
  const navigate = useNavigate();
  const [funnels, setFunnels] = useState<Funnel[]>([]);
  const [newFunnel, setNewFunnel] = useState({ name: "", description: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchFunnels();
  }, []);

  const fetchFunnels = async () => {
    const { data } = await supabase
      .from("funnels")
      .select("*")
      .order("created_at", { ascending: false });
    setFunnels(data || []);
  };

  const handleAddFunnel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFunnel.name) {
      toast.error("Preencha o nome do funil");
      return;
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.from("funnels").insert({
        name: newFunnel.name,
        description: newFunnel.description || null,
        is_active: true,
      });

      if (error) throw error;

      toast.success("Funil adicionado com sucesso!");
      setNewFunnel({ name: "", description: "" });
      fetchFunnels();
    } catch (error: any) {
      console.error("Error adding funnel:", error);
      toast.error(error.message || "Erro ao adicionar funil");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("funnels")
        .update({ is_active: !currentStatus })
        .eq("id", id);

      if (error) throw error;

      toast.success(`Funil ${!currentStatus ? "ativado" : "desativado"} com sucesso!`);
      fetchFunnels();
    } catch (error) {
      console.error("Error updating funnel:", error);
      toast.error("Erro ao atualizar funil");
    }
  };

  const handleDeleteFunnel = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este funil?")) return;

    try {
      const { error } = await supabase.from("funnels").delete().eq("id", id);

      if (error) throw error;

      toast.success("Funil excluído com sucesso!");
      fetchFunnels();
    } catch (error) {
      console.error("Error deleting funnel:", error);
      toast.error("Erro ao excluir funil");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="container mx-auto max-w-6xl">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Add New Funnel Form */}
          <Card className="shadow-xl lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Adicionar Funil
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddFunnel} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome do Funil</Label>
                  <Input
                    id="name"
                    value={newFunnel.name}
                    onChange={(e) => setNewFunnel({ ...newFunnel, name: e.target.value })}
                    placeholder="Ex: Facebook Ads"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={newFunnel.description}
                    onChange={(e) => setNewFunnel({ ...newFunnel, description: e.target.value })}
                    placeholder="Breve descrição do funil"
                    rows={3}
                  />
                </div>

                <Button type="submit" disabled={isSubmitting} className="w-full">
                  {isSubmitting ? "Adicionando..." : "Adicionar Funil"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Funnels List */}
          <Card className="shadow-xl lg:col-span-2">
            <CardHeader>
              <CardTitle>Funis Cadastrados</CardTitle>
            </CardHeader>
            <CardContent>
              {funnels.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Nenhum funil cadastrado ainda
                </p>
              ) : (
                <div className="space-y-4">
                  {funnels.map((funnel) => (
                    <div
                      key={funnel.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="font-semibold text-lg">{funnel.name}</div>
                        {funnel.description && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {funnel.description}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <Label htmlFor={`active-${funnel.id}`} className="text-sm">
                            {funnel.is_active ? "Ativo" : "Inativo"}
                          </Label>
                          <Switch
                            id={`active-${funnel.id}`}
                            checked={funnel.is_active}
                            onCheckedChange={() => handleToggleActive(funnel.id, funnel.is_active)}
                          />
                        </div>

                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteFunnel(funnel.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FunnelsManagement;
