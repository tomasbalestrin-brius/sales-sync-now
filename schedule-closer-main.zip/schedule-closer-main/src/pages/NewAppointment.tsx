import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Closer {
  id: string;
  name: string;
}

interface Funnel {
  id: string;
  name: string;
}

interface TimeSlot {
  time: string;
  available: boolean;
}

const NewAppointment = () => {
  const navigate = useNavigate();
  const [closers, setClosers] = useState<Closer[]>([]);
  const [funnels, setFunnels] = useState<Funnel[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedCloser, setSelectedCloser] = useState<string>("");
  const [leadName, setLeadName] = useState("");
  const [funnel, setFunnel] = useState("");
  const [availableSlots, setAvailableSlots] = useState<TimeSlot[]>([]);
  const [selectedTime, setSelectedTime] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchClosers();
    fetchFunnels();
  }, []);

  useEffect(() => {
    if (selectedDate && selectedCloser) {
      fetchAvailableSlots();
    }
  }, [selectedDate, selectedCloser]);

  const fetchClosers = async () => {
    const { data } = await supabase
      .from("closers")
      .select("id, name")
      .eq("is_active", true)
      .order("name");
    setClosers(data || []);
  };

  const fetchFunnels = async () => {
    const { data } = await supabase
      .from("funnels")
      .select("id, name")
      .eq("is_active", true)
      .order("name");
    setFunnels(data || []);
  };

  const generateTimeSlots = (startTime: string, endTime: string, duration: number) => {
    const slots: string[] = [];
    const start = new Date(`2000-01-01T${startTime}`);
    const end = new Date(`2000-01-01T${endTime}`);

    let current = start;
    while (current < end) {
      slots.push(format(current, "HH:mm:ss"));
      current = new Date(current.getTime() + duration * 60000);
    }
    return slots;
  };

  const fetchAvailableSlots = async () => {
    if (!selectedDate || !selectedCloser) return;

    const dayOfWeek = selectedDate.getDay();
    const formattedDate = format(selectedDate, "yyyy-MM-dd");

    // Get time configuration for the day
    const { data: config } = await supabase
      .from("time_slots_config")
      .select("*")
      .eq("day_of_week", dayOfWeek)
      .eq("is_active", true)
      .single();

    // Generate all possible slots
    const allSlots: string[] = [];
    if (config) {
      allSlots.push(
        ...generateTimeSlots(
          config.start_time,
          config.end_time,
          config.slot_duration_minutes
        )
      );
    }

    // Get custom slots for this date and closer
    const { data: customSlots } = await supabase
      .from("custom_time_slots")
      .select("*")
      .eq("closer_id", selectedCloser)
      .eq("date", formattedDate);

    // Add available custom slots to the list
    customSlots?.forEach((slot) => {
      if (slot.is_available && !allSlots.includes(slot.time)) {
        allSlots.push(slot.time);
      }
    });

    // Get existing appointments
    const { data: appointments } = await supabase
      .from("appointments")
      .select("scheduled_time")
      .eq("closer_id", selectedCloser)
      .eq("scheduled_date", formattedDate)
      .neq("status", "cancelled");

    const bookedTimes = new Set(appointments?.map((a) => a.scheduled_time) || []);

    // Get blocked custom slots
    const blockedTimes = new Set(
      customSlots?.filter((s) => !s.is_available).map((s) => s.time) || []
    );

    // Sort slots chronologically
    allSlots.sort();

    setAvailableSlots(
      allSlots.map((time) => ({
        time,
        available: !bookedTimes.has(time) && !blockedTimes.has(time),
      }))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!leadName || !funnel || !selectedDate || !selectedTime || !selectedCloser) {
      toast.error("Por favor, preencha todos os campos");
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase.from("appointments").insert({
        closer_id: selectedCloser,
        lead_name: leadName,
        funnel,
        scheduled_date: format(selectedDate, "yyyy-MM-dd"),
        scheduled_time: selectedTime,
        status: "scheduled",
      });

      if (error) throw error;

      toast.success("Agendamento criado com sucesso!");
      navigate("/");
    } catch (error) {
      console.error("Error creating appointment:", error);
      toast.error("Erro ao criar agendamento");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="container mx-auto max-w-4xl">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar ao Dashboard
        </Button>

        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="text-3xl">Novo Agendamento</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="leadName">Nome do Lead</Label>
                  <Input
                    id="leadName"
                    value={leadName}
                    onChange={(e) => setLeadName(e.target.value)}
                    placeholder="Digite o nome do lead"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Funil</Label>
                  <Select value={funnel} onValueChange={setFunnel} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um funil" />
                    </SelectTrigger>
                    <SelectContent>
                      {funnels.map((f) => (
                        <SelectItem key={f.id} value={f.name}>
                          {f.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Closer</Label>
                <Select value={selectedCloser} onValueChange={setSelectedCloser} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um closer" />
                  </SelectTrigger>
                  <SelectContent>
                    {closers.map((closer) => (
                      <SelectItem key={closer.id} value={closer.id}>
                        {closer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Data do Agendamento</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !selectedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate
                        ? format(selectedDate, "PPP", { locale: ptBR })
                        : "Selecione uma data"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      disabled={(date) => {
                        const day = date.getDay();
                        return day === 0 || day === 6 || date < new Date();
                      }}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {selectedDate && selectedCloser && (
                <div className="space-y-2">
                  <Label>Horário Disponível</Label>
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                    {availableSlots.length === 0 ? (
                      <p className="col-span-full text-center text-muted-foreground py-4">
                        Nenhum horário disponível para este dia
                      </p>
                    ) : (
                      availableSlots.map((slot) => (
                        <Button
                          key={slot.time}
                          type="button"
                          variant={selectedTime === slot.time ? "default" : "outline"}
                          disabled={!slot.available}
                          onClick={() => setSelectedTime(slot.time)}
                          className="w-full"
                        >
                          {format(new Date(`2000-01-01T${slot.time}`), "HH:mm")}
                        </Button>
                      ))
                    )}
                  </div>
                </div>
              )}

              <div className="flex gap-4 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/")}
                  className="flex-1"
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={isSubmitting} className="flex-1">
                  {isSubmitting ? "Criando..." : "Criar Agendamento"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NewAppointment;
